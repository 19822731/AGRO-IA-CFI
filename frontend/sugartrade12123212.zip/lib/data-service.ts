"use server"

// Tipos para los datos de azúcar
export interface PrecioHistorico {
  fecha: string
  precio: number
  volumen?: number
}

export interface DatoProduccion {
  region: string
  valor: number
  porcentaje: number
  periodo?: string
}

export interface DatoCorrelacion {
  fecha: string
  precio: number
  factor: number
  nombreFactor: string
}

export interface DatoGlobal {
  pais: string
  valor: number
  porcentaje: number
  tipo: "produccion" | "consumo" | "exportacion" | "importacion"
}

export interface DatoEstacional {
  mes: string
  promedio: number
  minimo: number
  maximo: number
}

export interface DatoProyeccion {
  fecha: string
  real: number | null
  proyectado: number
}

// Función para obtener datos históricos de precios
export async function obtenerPreciosHistoricos(): Promise<PrecioHistorico[]> {
  // Aquí se conectaría a tu API o base de datos
  // Por ahora, devolvemos datos de ejemplo que podrías reemplazar

  // Simulamos una pequeña latencia para simular una llamada a API
  await new Promise((resolve) => setTimeout(resolve, 300))

  return [
    { fecha: "2023-01-01", precio: 19.5, volumen: 150000 },
    { fecha: "2023-02-01", precio: 20.1, volumen: 145000 },
    { fecha: "2023-03-01", precio: 20.8, volumen: 160000 },
    { fecha: "2023-04-01", precio: 21.2, volumen: 155000 },
    { fecha: "2023-05-01", precio: 20.5, volumen: 148000 },
    { fecha: "2023-06-01", precio: 20.9, volumen: 152000 },
    { fecha: "2023-07-01", precio: 21.5, volumen: 158000 },
    { fecha: "2023-08-01", precio: 22.1, volumen: 162000 },
    { fecha: "2023-09-01", precio: 22.8, volumen: 170000 },
    { fecha: "2023-10-01", precio: 23.2, volumen: 175000 },
    { fecha: "2023-11-01", precio: 22.5, volumen: 168000 },
    { fecha: "2023-12-01", precio: 21.8, volumen: 160000 },
    { fecha: "2024-01-01", precio: 21.5, volumen: 155000 },
    { fecha: "2024-02-01", precio: 22.1, volumen: 158000 },
    { fecha: "2024-03-01", precio: 22.8, volumen: 162000 },
  ]
}

// Función para obtener datos de producción por período
export async function obtenerDatosProduccionPorPeriodo(): Promise<DatoProduccion[]> {
  await new Promise((resolve) => setTimeout(resolve, 300))

  return [
    { region: "Inicial", valor: 69602.5, porcentaje: 25, periodo: "Mayo-Junio" },
    { region: "Intermedio", valor: 130852.7, porcentaje: 47, periodo: "Julio-Septiembre" },
    { region: "Final", valor: 52897.9, porcentaje: 19, periodo: "Septiembre-Octubre" },
    { region: "Tardío", valor: 25056.9, porcentaje: 9, periodo: "Octubre-Noviembre" },
  ]
}

// Función para obtener datos de producción por departamento
export async function obtenerDatosProduccionPorDepartamento(): Promise<any[]> {
  await new Promise((resolve) => setTimeout(resolve, 300))

  return [
    { nombre: "Cruz Alta", inicial: 9500, intermedio: 22000, final: 8500, tardio: 5000, total: 45000 },
    { nombre: "Leales", inicial: 8000, intermedio: 18000, final: 6000, tardio: 2000, total: 34000 },
    { nombre: "Simoca", inicial: 7000, intermedio: 15000, final: 7500, tardio: 3500, total: 33000 },
    { nombre: "Burruyacu", inicial: 6500, intermedio: 14000, final: 7000, tardio: 2000, total: 29500 },
    { nombre: "Monteros", inicial: 5000, intermedio: 12000, final: 4000, tardio: 4000, total: 25000 },
    { nombre: "Chicligasta", inicial: 4500, intermedio: 10000, final: 3500, tardio: 2000, total: 20000 },
    { nombre: "Río Chico", inicial: 4000, intermedio: 9000, final: 3000, tardio: 1500, total: 17500 },
    { nombre: "Famaillá", inicial: 3500, intermedio: 8000, final: 2500, tardio: 1000, total: 15000 },
    { nombre: "La Cocha", inicial: 5500, intermedio: 7000, final: 2000, tardio: 500, total: 15000 },
    { nombre: "Graneros", inicial: 5000, intermedio: 6000, final: 1500, tardio: 300, total: 12800 },
  ]
}

// Función para obtener datos de progreso mensual
export async function obtenerProgresoMensual(): Promise<any[]> {
  await new Promise((resolve) => setTimeout(resolve, 300))

  return [
    { nombre: "Mayo", porcentaje: 10, hectareas: 27841 },
    { nombre: "Junio", porcentaje: 15, hectareas: 41761.5 },
    { nombre: "Julio", porcentaje: 20, hectareas: 55682 },
    { nombre: "Agosto", porcentaje: 15, hectareas: 41761.5 },
    { nombre: "Septiembre", porcentaje: 12, hectareas: 33409.2 },
    { nombre: "Octubre", porcentaje: 19, hectareas: 52897.9 },
    { nombre: "Noviembre", porcentaje: 9, hectareas: 25056.9 },
  ]
}

// Función para obtener datos globales
export async function obtenerDatosGlobales(
  tipo: "produccion" | "consumo" | "exportacion" | "importacion",
): Promise<DatoGlobal[]> {
  await new Promise((resolve) => setTimeout(resolve, 300))

  const datosProduccion = [
    { pais: "Brasil", valor: 39.4, porcentaje: 20.5, tipo: "produccion" as const },
    { pais: "India", valor: 33.8, porcentaje: 17.6, tipo: "produccion" as const },
    { pais: "Unión Europea", valor: 15.5, porcentaje: 8.1, tipo: "produccion" as const },
    { pais: "Tailandia", valor: 10.5, porcentaje: 5.5, tipo: "produccion" as const },
    { pais: "China", valor: 10.0, porcentaje: 5.2, tipo: "produccion" as const },
    { pais: "Estados Unidos", valor: 8.2, porcentaje: 4.3, tipo: "produccion" as const },
    { pais: "México", valor: 6.0, porcentaje: 3.1, tipo: "produccion" as const },
    { pais: "Pakistán", valor: 5.8, porcentaje: 3.0, tipo: "produccion" as const },
    { pais: "Rusia", valor: 5.6, porcentaje: 2.9, tipo: "produccion" as const },
    { pais: "Argentina", valor: 2.1, porcentaje: 1.1, tipo: "produccion" as const },
    { pais: "Otros", valor: 43.1, porcentaje: 28.7, tipo: "produccion" as const },
  ]

  const datosConsumo = [
    { pais: "India", valor: 28.5, porcentaje: 15.8, tipo: "consumo" as const },
    { pais: "Unión Europea", valor: 18.5, porcentaje: 10.3, tipo: "consumo" as const },
    { pais: "China", valor: 15.2, porcentaje: 8.4, tipo: "consumo" as const },
    { pais: "Brasil", valor: 10.7, porcentaje: 5.9, tipo: "consumo" as const },
    { pais: "Estados Unidos", valor: 10.5, porcentaje: 5.8, tipo: "consumo" as const },
    { pais: "Indonesia", valor: 7.4, porcentaje: 4.1, tipo: "consumo" as const },
    { pais: "Rusia", valor: 6.1, porcentaje: 3.4, tipo: "consumo" as const },
    { pais: "Pakistán", valor: 5.9, porcentaje: 3.3, tipo: "consumo" as const },
    { pais: "México", valor: 4.6, porcentaje: 2.6, tipo: "consumo" as const },
    { pais: "Egipto", valor: 3.2, porcentaje: 1.8, tipo: "consumo" as const },
    { pais: "Otros", valor: 69.4, porcentaje: 38.6, tipo: "consumo" as const },
  ]

  const datosExportacion = [
    { pais: "Brasil", valor: 29.8, porcentaje: 49.7, tipo: "exportacion" as const },
    { pais: "Tailandia", valor: 7.5, porcentaje: 12.5, tipo: "exportacion" as const },
    { pais: "India", valor: 6.0, porcentaje: 10.0, tipo: "exportacion" as const },
    { pais: "Australia", valor: 3.5, porcentaje: 5.8, tipo: "exportacion" as const },
    { pais: "Guatemala", valor: 2.0, porcentaje: 3.3, tipo: "exportacion" as const },
    { pais: "Unión Europea", valor: 1.5, porcentaje: 2.5, tipo: "exportacion" as const },
    { pais: "México", valor: 1.3, porcentaje: 2.2, tipo: "exportacion" as const },
    { pais: "Colombia", valor: 0.7, porcentaje: 1.2, tipo: "exportacion" as const },
    { pais: "Argentina", valor: 0.4, porcentaje: 0.7, tipo: "exportacion" as const },
    { pais: "Otros", valor: 7.3, porcentaje: 12.1, tipo: "exportacion" as const },
  ]

  const datosImportacion = [
    { pais: "Indonesia", valor: 5.2, porcentaje: 8.7, tipo: "importacion" as const },
    { pais: "China", valor: 5.0, porcentaje: 8.3, tipo: "importacion" as const },
    { pais: "Estados Unidos", valor: 3.0, porcentaje: 5.0, tipo: "importacion" as const },
    { pais: "Bangladesh", valor: 2.5, porcentaje: 4.2, tipo: "importacion" as const },
    { pais: "Argelia", valor: 2.2, porcentaje: 3.7, tipo: "importacion" as const },
    { pais: "Malasia", valor: 2.0, porcentaje: 3.3, tipo: "importacion" as const },
    { pais: "Corea del Sur", valor: 1.9, porcentaje: 3.2, tipo: "importacion" as const },
    { pais: "Nigeria", valor: 1.8, porcentaje: 3.0, tipo: "importacion" as const },
    { pais: "Emiratos Árabes", valor: 1.7, porcentaje: 2.8, tipo: "importacion" as const },
    { pais: "Egipto", valor: 1.5, porcentaje: 2.5, tipo: "importacion" as const },
    { pais: "Otros", valor: 33.2, porcentaje: 55.3, tipo: "importacion" as const },
  ]

  switch (tipo) {
    case "produccion":
      return datosProduccion
    case "consumo":
      return datosConsumo
    case "exportacion":
      return datosExportacion
    case "importacion":
      return datosImportacion
    default:
      return []
  }
}

// Función para obtener datos de correlación
export async function obtenerDatosCorrelacion(tipo: "produccion" | "clima" | "petroleo"): Promise<DatoCorrelacion[]> {
  await new Promise((resolve) => setTimeout(resolve, 300))

  const correlacionProduccion = [
    { fecha: "2013", precio: 17.5, factor: 180, nombreFactor: "produccion" },
    { fecha: "2014", precio: 16.2, factor: 183, nombreFactor: "produccion" },
    { fecha: "2015", precio: 13.1, factor: 177, nombreFactor: "produccion" },
    { fecha: "2016", precio: 18.1, factor: 174, nombreFactor: "produccion" },
    { fecha: "2017", precio: 15.8, factor: 179, nombreFactor: "produccion" },
    { fecha: "2018", precio: 12.5, factor: 185, nombreFactor: "produccion" },
    { fecha: "2019", precio: 13.7, factor: 183, nombreFactor: "produccion" },
    { fecha: "2020", precio: 14.9, factor: 178, nombreFactor: "produccion" },
    { fecha: "2021", precio: 19.3, factor: 181, nombreFactor: "produccion" },
    { fecha: "2022", precio: 18.2, factor: 176, nombreFactor: "produccion" },
    { fecha: "2023", precio: 20.5, factor: 180, nombreFactor: "produccion" },
  ]

  const correlacionClima = [
    { fecha: "2013", precio: 17.5, factor: 1200, nombreFactor: "precipitacion" },
    { fecha: "2014", precio: 16.2, factor: 1150, nombreFactor: "precipitacion" },
    { fecha: "2015", precio: 13.1, factor: 950, nombreFactor: "precipitacion" },
    { fecha: "2016", precio: 18.1, factor: 850, nombreFactor: "precipitacion" },
    { fecha: "2017", precio: 15.8, factor: 1050, nombreFactor: "precipitacion" },
    { fecha: "2018", precio: 12.5, factor: 1300, nombreFactor: "precipitacion" },
    { fecha: "2019", precio: 13.7, factor: 1250, nombreFactor: "precipitacion" },
    { fecha: "2020", precio: 14.9, factor: 1100, nombreFactor: "precipitacion" },
    { fecha: "2021", precio: 19.3, factor: 900, nombreFactor: "precipitacion" },
    { fecha: "2022", precio: 18.2, factor: 950, nombreFactor: "precipitacion" },
    { fecha: "2023", precio: 20.5, factor: 800, nombreFactor: "precipitacion" },
  ]

  const correlacionPetroleo = [
    { fecha: "2013", precio: 17.5, factor: 98, nombreFactor: "petroleo" },
    { fecha: "2014", precio: 16.2, factor: 93, nombreFactor: "petroleo" },
    { fecha: "2015", precio: 13.1, factor: 49, nombreFactor: "petroleo" },
    { fecha: "2016", precio: 18.1, factor: 44, nombreFactor: "petroleo" },
    { fecha: "2017", precio: 15.8, factor: 54, nombreFactor: "petroleo" },
    { fecha: "2018", precio: 12.5, factor: 71, nombreFactor: "petroleo" },
    { fecha: "2019", precio: 13.7, factor: 64, nombreFactor: "petroleo" },
    { fecha: "2020", precio: 14.9, factor: 42, nombreFactor: "petroleo" },
    { fecha: "2021", precio: 19.3, factor: 71, nombreFactor: "petroleo" },
    { fecha: "2022", precio: 18.2, factor: 99, nombreFactor: "petroleo" },
    { fecha: "2023", precio: 20.5, factor: 82, nombreFactor: "petroleo" },
  ]

  switch (tipo) {
    case "produccion":
      return correlacionProduccion
    case "clima":
      return correlacionClima
    case "petroleo":
      return correlacionPetroleo
    default:
      return []
  }
}

// Función para obtener datos estacionales
export async function obtenerDatosEstacionales(): Promise<DatoEstacional[]> {
  await new Promise((resolve) => setTimeout(resolve, 300))

  return [
    { mes: "Enero", promedio: 16.2, minimo: 12.8, maximo: 19.5 },
    { mes: "Febrero", promedio: 16.5, minimo: 13.1, maximo: 20.1 },
    { mes: "Marzo", promedio: 16.0, minimo: 11.2, maximo: 20.8 },
    { mes: "Abril", promedio: 16.2, minimo: 10.4, maximo: 21.2 },
    { mes: "Mayo", promedio: 16.0, minimo: 10.8, maximo: 20.5 },
    { mes: "Junio", promedio: 16.3, minimo: 11.5, maximo: 20.9 },
    { mes: "Julio", promedio: 16.4, minimo: 12.0, maximo: 21.5 },
    { mes: "Agosto", promedio: 16.6, minimo: 11.5, maximo: 22.1 },
    { mes: "Septiembre", promedio: 17.1, minimo: 11.8, maximo: 22.8 },
    { mes: "Octubre", promedio: 17.5, minimo: 12.4, maximo: 23.2 },
    { mes: "Noviembre", promedio: 17.7, minimo: 12.8, maximo: 22.5 },
    { mes: "Diciembre", promedio: 17.9, minimo: 13.2, maximo: 21.8 },
  ]
}

// Función para obtener datos de proyección
export async function obtenerDatosProyeccion(): Promise<DatoProyeccion[]> {
  await new Promise((resolve) => setTimeout(resolve, 300))

  return [
    { fecha: "Ene 2024", real: 21.5, proyectado: 21.5 },
    { fecha: "Feb 2024", real: 22.1, proyectado: 22.1 },
    { fecha: "Mar 2024", real: 22.8, proyectado: 22.8 },
    { fecha: "Abr 2024", real: null, proyectado: 23.2 },
    { fecha: "May 2024", real: null, proyectado: 23.5 },
    { fecha: "Jun 2024", real: null, proyectado: 23.8 },
    { fecha: "Jul 2024", real: null, proyectado: 24.1 },
    { fecha: "Ago 2024", real: null, proyectado: 24.3 },
    { fecha: "Sep 2024", real: null, proyectado: 24.5 },
    { fecha: "Oct 2024", real: null, proyectado: 24.7 },
    { fecha: "Nov 2024", real: null, proyectado: 24.9 },
    { fecha: "Dic 2024", real: null, proyectado: 25.0 },
  ]
}

// Función para obtener datos de volatilidad
export async function obtenerDatosVolatilidad(): Promise<any[]> {
  await new Promise((resolve) => setTimeout(resolve, 300))

  return [
    { año: "2019", volatilidad: 5.2 },
    { año: "2020", volatilidad: 12.8 },
    { año: "2021", volatilidad: 8.5 },
    { año: "2022", volatilidad: 6.7 },
    { año: "2023", volatilidad: 7.3 },
  ]
}
