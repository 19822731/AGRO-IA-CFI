// Tipos para los informes de azúcar
export interface SugarReport {
  report_date: string
  region: string
  topic: string
  production_forecast_2023?: number
  production_forecast_2024?: number
  production_estimate_2023?: number
  production_unit?: string
  export_forecast_2023?: number
  export_estimate_2023?: number
  export_unit?: string
  sugarcane_production_forecast_2023?: number
  sugarcane_production_forecast_2024?: number
  sugarcane_production_estimate_2023?: number
  sugarcane_unit?: string
  area_harvested_2023?: number
  area_unit?: string
  key_points: string[]
  historical_context: string[]
  production_exports_chart_data?: {
    years: string[]
    production: number[]
    exports: number[]
  }
  export_destinations?: string[]
  sugarcane_production_provinces?: {
    province: string
    percentage: number
  }[]
  sugarcane_production_divisions?: {
    division: string
  }[]
  sugarcane_planting_seasons?: string[]
  production_increase?: number
  production_increase_percent?: number
  sugarbeet_area_2024?: number
  area_decrease_percent_france?: number
  france_sugarbeet_area_percent?: number
  sugarbeet_planting_increases?: string[]
  production_by_country: {
    country: string[]
    production_values: {
      year: string
      value: string
    }[]
  }
}

// Datos de informes de azúcar
export const sugarReports: SugarReport[] = [
  {
    report_date: "May 2022",
    region: "Thailand",
    topic: "Sugar Production and Exports",
    production_forecast_2023: 10.5,
    production_unit: "million tons",
    export_forecast_2023: 11.0,
    export_unit: "million tons",
    sugarcane_production_forecast_2023: 98.3,
    sugarcane_unit: "million tons",
    area_harvested_2023: 1.6,
    area_unit: "million hectares",
    key_points: [
      "Production forecast to rise slightly.",
      "Exports expected to increase.",
      "Sugarcane production is forecast up.",
      "Area harvested expected to rise.",
    ],
    historical_context: [
      "Thailand has been the fourth largest sugar producer.",
      "Thailand has been the second largest exporter in 9 of the last 10 years.",
    ],
    production_exports_chart_data: {
      years: ["2018/19", "2019/20", "2020/21", "2021/22", "2022/23"],
      production: [14.0, 13.0, 8.0, 10.0, 10.5],
      exports: [12.0, 10.0, 6.0, 10.0, 11.0],
    },
    production_by_country: {
      country: [
        "Brazil",
        "India",
        "European Union",
        "Thailand",
        "China",
        "Indonesia",
        "United States",
        "Philippines",
        "Mexico",
        "Russia",
        "Bangladesh",
        "Vietnam",
      ],
      production_values: [
        {
          year: "2017/18",
          value: "39,121",
        },
        {
          year: "2018/19",
          value: "35,770",
        },
        {
          year: "2019/20",
          value: "30,105",
        },
        {
          year: "2020/21",
          value: "33,896",
        },
        {
          year: "2021/22",
          value: "36,560",
        },
        {
          year: "2022/23",
          value: "35,625",
        },
      ],
    },
  },
  {
    report_date: "November 2022",
    region: "Australia",
    topic: "Sugar Exports",
    production_estimate_2023: 4.4,
    production_unit: "million tons",
    sugarcane_production_estimate_2023: 33.0,
    sugarcane_unit: "million tons",
    area_harvested_2023: 350000,
    area_unit: "hectares",
    export_estimate_2023: 3.6,
    export_unit: "million tons",
    key_points: [
      "Sugar production estimated to rise slightly.",
      "Sugarcane production is estimated up.",
      "Sugar exports are estimated to increase.",
      "Ending stocks will be drawn down due to strong world demand.",
    ],
    historical_context: [
      "Australia has been the tenth largest sugar producer.",
      "Australia has been the fourth largest exporter, or better, for nearly a decade.",
    ],
    export_destinations: ["Indonesia", "Japan", "South Korea", "New Zealand", "Singapore", "United States"],
    production_by_country: {
      country: [
        "Brazil",
        "India",
        "Thailand",
        "China",
        "Pakistan",
        "Indonesia",
        "United States",
        "European Union",
        "Mexico",
        "Philippines",
        "Brazil",
        "Russia",
        "Bangladesh",
      ],
      production_values: [
        {
          year: "2017/18",
          value: "39,121",
        },
        {
          year: "2018/19",
          value: "35,770",
        },
        {
          year: "2019/20",
          value: "30,105",
        },
        {
          year: "2020/21",
          value: "33,896",
        },
        {
          year: "2021/22",
          value: "36,560",
        },
        {
          year: "2022/23",
          value: "35,625",
        },
      ],
    },
  },
  {
    report_date: "May 2023",
    region: "Pakistan",
    topic: "Sugar Production",
    production_forecast_2024: 7.1,
    production_unit: "million tons",
    production_increase: 250000,
    sugarcane_production_forecast_2024: 83.5,
    sugarcane_unit: "million tons",
    production_increase_percent: 3,
    sugarcane_production_provinces: [
      {
        province: "Punjab",
        percentage: 68,
      },
      {
        province: "Sindh",
        percentage: 24,
      },
      {
        province: "Khyber Pakhtunkhwa (KPK)",
        percentage: 8,
      },
    ],
    sugarcane_production_divisions: [
      {
        division: "Bahawalpur (Punjab)",
      },
      {
        division: "Sukkur (Sindh)",
      },
    ],
    sugarcane_planting_seasons: ["Spring (February to March)", "Fall (September to October)"],
    key_points: [
      "Sugar production is forecast to rise due to recovery in sugarcane area harvested.",
      "Sugarcane production is forecast up.",
      "Favorable prices are encouraging farmers to maintain sugarcane area.",
      "Sugarcane is produced in three provinces.",
      "Sugarcane is planted in two different seasons.",
      "Yields per hectare are relatively low due to various factors.",
    ],
    historical_context: ["Pakistan has been one of the top eight sugar producers for the past 3 years."],
    production_by_country: {
      country: [
        "Brazil",
        "India",
        "Thailand",
        "China",
        "European Union",
        "Philippines",
        "United States",
        "Mexico",
        "Brazil",
        "Russia",
        "Bangladesh",
      ],
      production_values: [
        {
          year: "2018/19",
          value: "35,770",
        },
        {
          year: "2019/20",
          value: "30,105",
        },
        {
          year: "2020/21",
          value: "33,896",
        },
        {
          year: "2021/22",
          value: "36,560",
        },
        {
          year: "2022/23",
          value: "35,625",
        },
        {
          year: "2023/24",
          value: "38,570",
        },
      ],
    },
  },
  {
    report_date: "November 2023",
    region: "European Union",
    topic: "Sugar Production",
    production_forecast_2024: 15.5,
    production_unit: "million tons",
    sugarbeet_area_2024: 1.4,
    area_unit: "million hectares",
    production_increase_percent: 3,
    area_decrease_percent_france: 6,
    france_sugarbeet_area_percent: 28,
    sugarbeet_planting_increases: ["Poland (+19 percent)", "Spain", "Romania", "Slovakia", "Hungary"],
    key_points: [
      "EU beet sugar production is forecast up despite lower area in France.",
      "Reduced beet acreage in France is balanced by increased plantings in other countries.",
      "European Court of Justice (ECJ) ruling has impacted sugarbeet production.",
      "Neonicotinoids ban has caused French farmers to switch to other crops.",
      "Profitability of sugarbeet production in Poland is high.",
    ],
    production_by_country: {
      country: [
        "India",
        "Thailand",
        "China",
        "Indonesia",
        "United States",
        "European Union",
        "Philippines",
        "China",
        "Mexico",
        "Russia",
        "Iran",
        "Vietnam",
      ],
      production_values: [
        {
          year: "2019/20",
          value: "30,105",
        },
        {
          year: "2020/21",
          value: "33,896",
        },
        {
          year: "2021/22",
          value: "36,560",
        },
        {
          year: "2022/23",
          value: "35,625",
        },
        {
          year: "2023/24",
          value: "38,570",
        },
        {
          year: "2024/25",
          value: "37,840",
        },
      ],
    },
  },
]

// Función para obtener todos los informes
export function getAllReports() {
  return sugarReports
}

// Función para obtener un informe por región
export function getReportByRegion(region: string) {
  return sugarReports.find((report) => report.region.toLowerCase() === region.toLowerCase())
}

// Función para obtener las regiones disponibles
export function getAvailableRegions() {
  return sugarReports.map((report) => report.region)
}

// Función para obtener datos de producción global
export function getGlobalProductionData() {
  // Combinar datos de producción de todos los informes
  const allYears = new Set<string>()
  const countryData = {}

  sugarReports.forEach((report) => {
    report.production_by_country.production_values.forEach((yearData) => {
      allYears.add(yearData.year)
    })

    report.production_by_country.country.forEach((country, index) => {
      if (!countryData[country]) {
        countryData[country] = {}
      }
    })
  })

  // Ordenar años cronológicamente
  const sortedYears = Array.from(allYears).sort()

  return {
    years: sortedYears,
    countries: Object.keys(countryData),
    data: countryData,
  }
}
