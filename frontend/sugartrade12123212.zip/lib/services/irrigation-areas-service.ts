// Metadatos de las áreas de riego
export const irrigationMetadata = {
  title: "Capa de Áreas bajo riego de la provincia de Tucumán",
  abstract:
    "Capa vectorial disponible en el servicio WMS de la Red de Información para el Desarrollo Productivo. Contiene información espacial de las áreas bajo riego de la provincia de Tucumán. Fuente: Red de Información para el Desarrollo Productivo",
  dateCreated: "2017-05-28T11:02:00",
  organization: "RIDES - Red de Información para el Desarrollo Productivo",
  contact: "rides@producciontucuman.gob.ar",
  referenceSystem: "POSGAR 98 - Faja 3",
  summary: "Visualización de áreas de riego para cultivos de caña de azúcar y otros cultivos en la región.",
}

// Datos de ejemplo para las áreas de riego (simulados basados en los metadatos)
export const irrigationAreas = [
  {
    properties: {
      id: 1,
      name: "Zona Norte - Río Grande",
      efficiency: 0.85,
      waterSource: "Río Grande",
      mainCrops: ["Caña de azúcar", "Maíz"],
      area: 5200,
      irrigationType: "Goteo",
    },
    geometry: {
      type: "Polygon",
      coordinates: [
        [
          [-65.1, -26.7],
          [-65.0, -26.7],
          [-65.0, -26.6],
          [-65.1, -26.6],
          [-65.1, -26.7],
        ],
      ],
    },
  },
  {
    properties: {
      id: 2,
      name: "Zona Sur - Canal Principal",
      efficiency: 0.65,
      waterSource: "Canal Principal",
      mainCrops: ["Caña de azúcar", "Soja"],
      area: 4800,
      irrigationType: "Aspersión",
    },
    geometry: {
      type: "Polygon",
      coordinates: [
        [
          [-65.3, -26.9],
          [-65.2, -26.9],
          [-65.2, -26.8],
          [-65.3, -26.8],
          [-65.3, -26.9],
        ],
      ],
    },
  },
  {
    properties: {
      id: 3,
      name: "Zona Este - Pozo",
      efficiency: 0.45,
      waterSource: "Pozo",
      mainCrops: ["Caña de azúcar"],
      area: 3200,
      irrigationType: "Inundación",
    },
    geometry: {
      type: "Polygon",
      coordinates: [
        [
          [-65.0, -26.8],
          [-64.9, -26.8],
          [-64.9, -26.7],
          [-65.0, -26.7],
          [-65.0, -26.8],
        ],
      ],
    },
  },
  {
    properties: {
      id: 4,
      name: "Zona Oeste - Río Salí",
      efficiency: 0.72,
      waterSource: "Río Salí",
      mainCrops: ["Caña de azúcar", "Cítricos"],
      area: 4100,
      irrigationType: "Goteo",
    },
    geometry: {
      type: "Polygon",
      coordinates: [
        [
          [-65.4, -26.7],
          [-65.3, -26.7],
          [-65.3, -26.6],
          [-65.4, -26.6],
          [-65.4, -26.7],
        ],
      ],
    },
  },
  {
    properties: {
      id: 5,
      name: "Zona Central - Canal Secundario",
      efficiency: 0.58,
      waterSource: "Canal Secundario",
      mainCrops: ["Caña de azúcar", "Hortalizas"],
      area: 2700,
      irrigationType: "Aspersión",
    },
    geometry: {
      type: "Polygon",
      coordinates: [
        [
          [-65.2, -26.75],
          [-65.1, -26.75],
          [-65.1, -26.65],
          [-65.2, -26.65],
          [-65.2, -26.75],
        ],
      ],
    },
  },
]

// Función para obtener estadísticas de las áreas de riego
export function getIrrigationStatistics() {
  const totalArea = irrigationAreas.reduce((sum, area) => sum + area.properties.area, 0)

  const sugarCaneAreas = irrigationAreas.filter((area) => area.properties.mainCrops.includes("Caña de azúcar"))

  const sugarCaneArea = sugarCaneAreas.reduce((sum, area) => sum + area.properties.area, 0)
  const sugarCanePercentage = (sugarCaneArea / totalArea) * 100

  const avgEfficiency =
    irrigationAreas.reduce((sum, area) => sum + area.properties.efficiency, 0) / irrigationAreas.length

  return {
    totalArea,
    sugarCaneArea,
    sugarCanePercentage,
    avgEfficiency,
    areaCount: irrigationAreas.length,
  }
}

// Función para obtener áreas por tipo de riego
export function getIrrigationTypeDistribution() {
  const types = {}

  irrigationAreas.forEach((area) => {
    const type = area.properties.irrigationType
    if (!types[type]) {
      types[type] = 0
    }
    types[type] += area.properties.area
  })

  return Object.entries(types).map(([type, area]) => ({
    type,
    area,
    percentage: (Number(area) / getIrrigationStatistics().totalArea) * 100,
  }))
}

// Función para obtener áreas por eficiencia
export function getEfficiencyDistribution() {
  return [
    {
      label: "Alta (≥ 0.7)",
      count: irrigationAreas.filter((a) => a.properties.efficiency >= 0.7).length,
      area: irrigationAreas
        .filter((a) => a.properties.efficiency >= 0.7)
        .reduce((sum, area) => sum + area.properties.area, 0),
    },
    {
      label: "Media (≥ 0.5 y < 0.7)",
      count: irrigationAreas.filter((a) => a.properties.efficiency >= 0.5 && a.properties.efficiency < 0.7).length,
      area: irrigationAreas
        .filter((a) => a.properties.efficiency >= 0.5 && a.properties.efficiency < 0.7)
        .reduce((sum, area) => sum + area.properties.area, 0),
    },
    {
      label: "Baja (< 0.5)",
      count: irrigationAreas.filter((a) => a.properties.efficiency < 0.5).length,
      area: irrigationAreas
        .filter((a) => a.properties.efficiency < 0.5)
        .reduce((sum, area) => sum + area.properties.area, 0),
    },
  ]
}
