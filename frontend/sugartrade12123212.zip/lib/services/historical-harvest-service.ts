import type { DepartmentData } from "@/types/geography"

export interface HarvestLevel {
  id: string
  name: string
  minValue: number
  maxValue: number
  color: string
}

export interface HistoricalHarvestData {
  year: number
  departmentData: DepartmentData[]
  source: string
  harvestLevels: HarvestLevel[]
  totalArea: number
  totalProduction: number
  averageYield: number
}

// Niveles de producción según el mapa de zafra 2016
const HARVEST_LEVELS_2016: HarvestLevel[] = [
  {
    id: "very-high",
    name: "Muy Alto",
    minValue: 90,
    maxValue: 110,
    color: "#006400", // Verde oscuro
  },
  {
    id: "high",
    name: "Alto",
    minValue: 75,
    maxValue: 90,
    color: "#32CD32", // Verde lima
  },
  {
    id: "medium",
    name: "Medio",
    minValue: 60,
    maxValue: 75,
    color: "#FFFF00", // Amarillo
  },
  {
    id: "low",
    name: "Bajo",
    minValue: 45,
    maxValue: 60,
    color: "#FFA500", // Naranja
  },
  {
    id: "very-low",
    name: "Muy Bajo",
    minValue: 30,
    maxValue: 45,
    color: "#FF0000", // Rojo
  },
]

// Datos de producción por departamento basados en el mapa de zafra 2016
// Estos datos son aproximados basados en la descripción del mapa
export const HARVEST_DATA_2016: HistoricalHarvestData = {
  year: 2016,
  source: "Estación Experimental Agroindustrial Obispo Colombres",
  harvestLevels: HARVEST_LEVELS_2016,
  totalArea: 265000, // hectáreas aproximadas
  totalProduction: 15200000, // toneladas aproximadas
  averageYield: 57.3, // toneladas/hectárea aproximadas
  departmentData: [
    {
      id: "leales",
      name: "Leales",
      area: 42000,
      production: 3780000,
      yield: 90,
      levelId: "very-high",
      coordinates: { lat: -27.2, lng: -65.1 },
    },
    {
      id: "cruz-alta",
      name: "Cruz Alta",
      area: 48000,
      production: 4080000,
      yield: 85,
      levelId: "high",
      coordinates: { lat: -26.9, lng: -64.95 },
    },
    {
      id: "chicligasta",
      name: "Chicligasta",
      area: 32000,
      production: 2560000,
      yield: 80,
      levelId: "high",
      coordinates: { lat: -27.4, lng: -65.3 },
    },
    {
      id: "rio-chico",
      name: "Río Chico",
      area: 28000,
      production: 1960000,
      yield: 70,
      levelId: "medium",
      coordinates: { lat: -27.5, lng: -65.5 },
    },
    {
      id: "monteros",
      name: "Monteros",
      area: 30000,
      production: 2100000,
      yield: 70,
      levelId: "medium",
      coordinates: { lat: -27.2, lng: -65.5 },
    },
    {
      id: "famailla",
      name: "Famaillá",
      area: 25000,
      production: 1625000,
      yield: 65,
      levelId: "medium",
      coordinates: { lat: -27.05, lng: -65.4 },
    },
    {
      id: "simoca",
      name: "Simoca",
      area: 22000,
      production: 1100000,
      yield: 50,
      levelId: "low",
      coordinates: { lat: -27.3, lng: -65.2 },
    },
    {
      id: "graneros",
      name: "Graneros",
      area: 18000,
      production: 810000,
      yield: 45,
      levelId: "low",
      coordinates: { lat: -27.65, lng: -65.0 },
    },
    {
      id: "burruyacu",
      name: "Burruyacú",
      area: 12000,
      production: 420000,
      yield: 35,
      levelId: "very-low",
      coordinates: { lat: -26.5, lng: -64.7 },
    },
    {
      id: "tafi-viejo",
      name: "Tafí Viejo",
      area: 8000,
      production: 280000,
      yield: 35,
      levelId: "very-low",
      coordinates: { lat: -26.7, lng: -65.3 },
    },
  ],
}

// Función para obtener datos históricos de zafra por año
export function getHistoricalHarvestData(year: number): HistoricalHarvestData | null {
  if (year === 2016) {
    return HARVEST_DATA_2016
  }
  return null
}

// Función para obtener datos de un departamento específico
export function getDepartmentData(year: number, departmentId: string): DepartmentData | null {
  const harvestData = getHistoricalHarvestData(year)
  if (!harvestData) return null

  return harvestData.departmentData.find((dept) => dept.id === departmentId) || null
}

// Función para obtener el nivel de producción según el rendimiento
export function getProductionLevel(year: number, yield_: number): HarvestLevel | null {
  const harvestData = getHistoricalHarvestData(year)
  if (!harvestData) return null

  return harvestData.harvestLevels.find((level) => yield_ >= level.minValue && yield_ < level.maxValue) || null
}

// Función para obtener estadísticas comparativas entre años
export function getComparativeStats(baseYear: number, compareYear?: number) {
  // Por ahora solo tenemos datos de 2016, pero esta función está preparada
  // para cuando tengamos datos de más años para comparar
  const baseData = getHistoricalHarvestData(baseYear)
  if (!baseData) return null

  // Si no hay año de comparación o no tenemos datos de ese año,
  // devolvemos solo las estadísticas del año base
  if (!compareYear) {
    return {
      baseYear,
      baseData,
      comparison: null,
    }
  }

  const compareData = getHistoricalHarvestData(compareYear)
  if (!compareData) {
    return {
      baseYear,
      baseData,
      comparison: null,
    }
  }

  // Calculamos las diferencias
  const productionDiff = compareData.totalProduction - baseData.totalProduction
  const areaDiff = compareData.totalArea - baseData.totalArea
  const yieldDiff = compareData.averageYield - baseData.averageYield

  return {
    baseYear,
    baseData,
    compareYear,
    compareData,
    comparison: {
      productionDiff,
      productionDiffPercent: (productionDiff / baseData.totalProduction) * 100,
      areaDiff,
      areaDiffPercent: (areaDiff / baseData.totalArea) * 100,
      yieldDiff,
      yieldDiffPercent: (yieldDiff / baseData.averageYield) * 100,
    },
  }
}

// URL de la imagen original del mapa
export const HARVEST_2016_MAP_URL =
  "http://rides.producciontucuman.gov.ar/wp-content/uploads/2016/11/Rendimiento_ca%C3%B1a_2016.png"
export const HARVEST_2016_PDF_URL =
  "http://rides.producciontucuman.gov.ar/wp-content/uploads/2016/11/Rendimiento_ca%C3%B1a_2016.pdf"
