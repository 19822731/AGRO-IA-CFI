// Interfaz para los datos de precio
export interface PrecioAzucar {
  id?: number
  mercado: string
  fecha: string
  precio: number
  unidad: string
  datos_json?: string | object
}

// Función para guardar un nuevo precio
export async function guardarPrecioAzucar(datos: Omit<PrecioAzucar, "id">): Promise<PrecioAzucar> {
  try {
    const response = await fetch("/api/precios-azucar", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(datos),
    })

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.error || `Error HTTP: ${response.status}`)
    }

    const result = await response.json()
    return result.datos
  } catch (error) {
    console.error("Error al guardar precio del azúcar:", error)
    throw error
  }
}

// Función para obtener precios
export async function obtenerPreciosAzucar(mercado = "Interno", limite = 30): Promise<PrecioAzucar[]> {
  try {
    const response = await fetch(`/api/precios-azucar?mercado=${encodeURIComponent(mercado)}&limite=${limite}`)

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.error || `Error HTTP: ${response.status}`)
    }

    const result = await response.json()
    return result.precios
  } catch (error) {
    console.error("Error al obtener precios del azúcar:", error)
    throw error
  }
}
