// Interfaz para los datos de precio
export interface PrecioInterno {
  id?: number
  mercado: string
  fecha: string
  precio: number
  unidad: string
  datos_json?: string | object
}

// Función para guardar un nuevo precio
export async function guardarPrecioInterno(datos: {
  fecha: string
  precio: number
  unidad: string
  otros_datos?: Record<string, any>
}): Promise<PrecioInterno> {
  try {
    const response = await fetch("/api/precios-interno", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(datos),
    })

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.error || `Error HTTP: ${response.status}`)
    }

    const result = await response.json()
    return result.datos
  } catch (error) {
    console.error("Error al guardar precio interno:", error)
    throw error
  }
}

// Función para obtener precios
export async function obtenerPreciosInternos(limite = 30): Promise<PrecioInterno[]> {
  try {
    const response = await fetch(`/api/precios-interno?limite=${limite}`)

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.error || `Error HTTP: ${response.status}`)
    }

    const result = await response.json()
    return result.precios
  } catch (error) {
    console.error("Error al obtener precios internos:", error)
    throw error
  }
}
