import { parse } from "papaparse"

export interface SugarDataEntry {
  fuente: string
  tipoDato: string
  subtipoDato: string
  valor: string
  unidad: string
  fecha: string
  ubicacion: string
  notas: string
  valorNumerico?: number
  fechaObj?: Date
}

export class CsvDataService {
  private data: SugarDataEntry[] = []
  private isDataLoaded = false

  async loadData(csvContent: string): Promise<void> {
    return new Promise((resolve) => {
      parse(csvContent, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          this.data = results.data.map((row: any) => {
            // Normalizar nombres de columnas
            const entry: SugarDataEntry = {
              fuente: row.Fuente || "",
              tipoDato: row["Tipo de Dato"] || "",
              subtipoDato: row["Subtipo de Dato"] || "",
              valor: row.Valor || "",
              unidad: row.Unidad || "",
              fecha: row.Fecha || "",
              ubicacion: row.Ubicación || "",
              notas: row.Notas || "",
            }

            // Convertir valor a numérico si es posible
            const numericValue = this.extractNumericValue(entry.valor)
            if (numericValue !== null) {
              entry.valorNumerico = numericValue
            }

            // Convertir fecha a objeto Date si es posible
            try {
              if (entry.fecha && !isNaN(Date.parse(entry.fecha))) {
                entry.fechaObj = new Date(entry.fecha)
              }
            } catch (e) {
              // Fecha no válida, dejar como string
            }

            return entry
          })
          this.isDataLoaded = true
          resolve()
        },
      })
    })
  }

  private extractNumericValue(value: string): number | null {
    // Manejar rangos (e.g., "750-780")
    if (value.includes("-")) {
      const [min, max] = value.split("-").map((v) => Number.parseFloat(v.trim()))
      if (!isNaN(min) && !isNaN(max)) {
        return (min + max) / 2 // Usar el promedio del rango
      }
    }

    // Manejar valores simples
    const numericValue = Number.parseFloat(value.replace(/,/g, ""))
    return isNaN(numericValue) ? null : numericValue
  }

  getData(): SugarDataEntry[] {
    return this.data
  }

  getDataByType(type: string): SugarDataEntry[] {
    return this.data.filter((entry) => entry.tipoDato.toLowerCase() === type.toLowerCase())
  }

  getDataByLocation(location: string): SugarDataEntry[] {
    return this.data.filter((entry) => entry.ubicacion.toLowerCase().includes(location.toLowerCase()))
  }

  getDataByDateRange(startDate: Date, endDate: Date): SugarDataEntry[] {
    return this.data.filter((entry) => {
      if (!entry.fechaObj) return false
      return entry.fechaObj >= startDate && entry.fechaObj <= endDate
    })
  }

  getUniqueLocations(): string[] {
    const locations = new Set<string>()
    this.data.forEach((entry) => {
      if (entry.ubicacion) locations.add(entry.ubicacion)
    })
    return Array.from(locations)
  }

  getUniqueDataTypes(): string[] {
    const types = new Set<string>()
    this.data.forEach((entry) => {
      if (entry.tipoDato) types.add(entry.tipoDato)
    })
    return Array.from(types)
  }

  getTimeSeriesData(type: string, subtype: string, location?: string): { date: Date; value: number }[] {
    return this.data
      .filter(
        (entry) =>
          entry.tipoDato.toLowerCase() === type.toLowerCase() &&
          entry.subtipoDato.toLowerCase().includes(subtype.toLowerCase()) &&
          (location ? entry.ubicacion.toLowerCase().includes(location.toLowerCase()) : true) &&
          entry.fechaObj !== undefined &&
          entry.valorNumerico !== undefined,
      )
      .map((entry) => ({
        date: entry.fechaObj!,
        value: entry.valorNumerico!,
      }))
      .sort((a, b) => a.date.getTime() - b.date.getTime())
  }

  isLoaded(): boolean {
    return this.isDataLoaded
  }
}

// Singleton instance
export const csvDataService = new CsvDataService()
