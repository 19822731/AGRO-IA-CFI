export interface SugarFacility {
  id: string
  name: string
  type: "ingenio" | "cooperativa"
  location: {
    lat: number
    lng: number
  }
  capacity?: number // Capacidad de molienda en toneladas/día
  production?: number // Producción anual estimada en toneladas
  employees?: number // Número aproximado de empleados
  foundedYear?: number // Año de fundación
}

// Datos de ejemplo de ingenios y cooperativas en Tucumán
// En una implementación real, estos datos vendrían de una API o base de datos
export const sugarFacilities: SugarFacility[] = [
  {
    id: "ing-concepcion",
    name: "Ingenio Concepción",
    type: "ingenio",
    location: {
      lat: -26.7333,
      lng: -65.2333,
    },
    capacity: 16000,
    production: 180000,
    employees: 1200,
    foundedYear: 1835,
  },
  {
    id: "ing-leales",
    name: "Ingenio Leales",
    type: "ingenio",
    location: {
      lat: -27.0333,
      lng: -65.1167,
    },
    capacity: 9000,
    production: 120000,
    employees: 800,
    foundedYear: 1882,
  },
  {
    id: "ing-cruz-alta",
    name: "Ingenio Cruz Alta",
    type: "ingenio",
    location: {
      lat: -26.9167,
      lng: -64.9667,
    },
    capacity: 12000,
    production: 150000,
    employees: 950,
    foundedYear: 1870,
  },
  {
    id: "ing-la-florida",
    name: "Ingenio La Florida",
    type: "ingenio",
    location: {
      lat: -26.8,
      lng: -65.0833,
    },
    capacity: 14000,
    production: 165000,
    employees: 1100,
    foundedYear: 1894,
  },
  {
    id: "ing-la-corona",
    name: "Ingenio La Corona",
    type: "ingenio",
    location: {
      lat: -26.95,
      lng: -65.1833,
    },
    capacity: 10000,
    production: 130000,
    employees: 850,
    foundedYear: 1915,
  },
  {
    id: "coop-cañeros-unidos",
    name: "Cooperativa Cañeros Unidos",
    type: "cooperativa",
    location: {
      lat: -26.85,
      lng: -65.2,
    },
    employees: 350,
    foundedYear: 1945,
  },
  {
    id: "coop-productores-sur",
    name: "Cooperativa Productores del Sur",
    type: "cooperativa",
    location: {
      lat: -27.1,
      lng: -65.3,
    },
    employees: 280,
    foundedYear: 1962,
  },
  {
    id: "coop-union-cañera",
    name: "Cooperativa Unión Cañera",
    type: "cooperativa",
    location: {
      lat: -26.7833,
      lng: -65.05,
    },
    employees: 320,
    foundedYear: 1953,
  },
]

export const mapMetadata = {
  title: "Mapa de Actividades Azucareras para el año 2024 de la Provincia de Tucumán",
  summary:
    "Estación Experimental Agroindustrial Obispo Colombres (EEAOC). (2024). Mapa elaborado por el equipo SIG de la Red de Información para el Desarrollo Productivo, que muestra la localización de los diferentes ingenios y cooperativas cañeras en la provincia de Tucumán [Archivo PDF y PNG].",
  publicationDate: "2025-01-13T11:02:00",
  metadataCreationDate: "2025-02-13T12:31:20",
  geographicExtent: {
    west: -66.31347656250001,
    east: -64.37988281250001,
    south: -28.03804641936992,
    north: -26.08145445860753,
  },
}

export function getFacilitiesByType(type?: "ingenio" | "cooperativa"): SugarFacility[] {
  if (!type) return sugarFacilities
  return sugarFacilities.filter((facility) => facility.type === type)
}

export function getFacilityById(id: string): SugarFacility | undefined {
  return sugarFacilities.find((facility) => facility.id === id)
}

export function getFacilityStats() {
  const ingenios = sugarFacilities.filter((f) => f.type === "ingenio")
  const cooperativas = sugarFacilities.filter((f) => f.type === "cooperativa")

  const totalProduction = ingenios.reduce((sum, ing) => sum + (ing.production || 0), 0)
  const totalCapacity = ingenios.reduce((sum, ing) => sum + (ing.capacity || 0), 0)
  const totalEmployees = sugarFacilities.reduce((sum, f) => sum + (f.employees || 0), 0)

  return {
    totalIngenios: ingenios.length,
    totalCooperativas: cooperativas.length,
    totalProduction,
    totalCapacity,
    totalEmployees,
    averageProductionPerIngenio: totalProduction / (ingenios.length || 1),
    averageCapacityPerIngenio: totalCapacity / (ingenios.length || 1),
  }
}
