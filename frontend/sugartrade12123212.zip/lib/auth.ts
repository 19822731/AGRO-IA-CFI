import type { NextRequest } from "next/server"
import { jwtVerify } from "jose"
import { config } from "./config"

const JWT_SECRET = config.jwtSecret || "tu-secreto-seguro"

export async function verificarToken(request: NextRequest) {
  try {
    const token = request.headers.get("Authorization")?.split(" ")[1]

    if (!token) {
      return { autenticado: false, error: "Token no proporcionado" }
    }

    const { payload } = await jwtVerify(token, new TextEncoder().encode(JWT_SECRET))

    return { autenticado: true, usuario: payload.sub }
  } catch (error) {
    return { autenticado: false, error: "Token inválido" }
  }
}
