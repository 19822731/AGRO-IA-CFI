type LogLevel = "debug" | "info" | "warn" | "error"

interface LogEntry {
  timestamp: Date
  level: LogLevel
  module: string
  message: string
  data?: any
}

class Logger {
  private static instance: Logger
  private logs: LogEntry[] = []
  private maxLogs = 1000
  private logLevel: LogLevel = "info"
  private enableConsoleOutput = true
  private persistentStorage = false

  private constructor() {
    // En desarrollo, mostramos todos los niveles
    if (typeof window !== "undefined" && process.env.NODE_ENV === "development") {
      this.logLevel = "debug"
      this.tryRestoreLogs()
    }
  }

  public static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger()
    }
    return Logger.instance
  }

  public setLogLevel(level: LogLevel): void {
    this.logLevel = level
  }

  public setConsoleOutput(enable: boolean): void {
    this.enableConsoleOutput = enable
  }

  public setPersistentStorage(enable: boolean): void {
    this.persistentStorage = enable
    if (enable) {
      this.saveLogs()
    }
  }

  public debug(module: string, message: string, data?: any): void {
    this.log("debug", module, message, data)
  }

  public info(module: string, message: string, data?: any): void {
    this.log("info", module, message, data)
  }

  public warn(module: string, message: string, data?: any): void {
    this.log("warn", module, message, data)
  }

  public error(module: string, message: string, data?: any): void {
    this.log("error", module, message, data)
  }

  public getLogs(level?: LogLevel, module?: string, limit?: number): LogEntry[] {
    let filteredLogs = this.logs

    if (level) {
      filteredLogs = filteredLogs.filter((log) => log.level === level)
    }

    if (module) {
      filteredLogs = filteredLogs.filter((log) => log.module === module)
    }

    if (limit && limit > 0) {
      return filteredLogs.slice(-limit)
    }

    return filteredLogs
  }

  public clearLogs(): void {
    this.logs = []
    if (this.persistentStorage && typeof window !== "undefined") {
      try {
        localStorage.removeItem("app_logs")
      } catch (e) {
        console.error("Failed to clear logs from localStorage:", e)
      }
    }
  }

  private log(level: LogLevel, module: string, message: string, data?: any): void {
    // Verificar si debemos registrar este nivel
    if (!this.shouldLog(level)) {
      return
    }

    const entry: LogEntry = {
      timestamp: new Date(),
      level,
      module,
      message,
      data,
    }

    // Agregar al registro interno
    this.logs.push(entry)

    // Limitar el tamaño del registro
    if (this.logs.length > this.maxLogs) {
      this.logs.shift()
    }

    // Salida a la consola si está habilitada
    if (this.enableConsoleOutput) {
      this.logToConsole(entry)
    }

    // Guardar en almacenamiento persistente si está habilitado
    if (this.persistentStorage) {
      this.saveLogs()
    }
  }

  private shouldLog(level: LogLevel): boolean {
    const levels: LogLevel[] = ["debug", "info", "warn", "error"]
    const currentLevelIndex = levels.indexOf(this.logLevel)
    const logLevelIndex = levels.indexOf(level)

    return logLevelIndex >= currentLevelIndex
  }

  private logToConsole(entry: LogEntry): void {
    const timestamp = entry.timestamp.toISOString()
    const prefix = `[${timestamp}] [${entry.level.toUpperCase()}] [${entry.module}]:`

    switch (entry.level) {
      case "debug":
        console.debug(prefix, entry.message, entry.data || "")
        break
      case "info":
        console.info(prefix, entry.message, entry.data || "")
        break
      case "warn":
        console.warn(prefix, entry.message, entry.data || "")
        break
      case "error":
        console.error(prefix, entry.message, entry.data || "")
        break
    }
  }

  private saveLogs(): void {
    if (typeof window === "undefined") return

    try {
      // Solo guardar los últimos 100 logs para no sobrecargar localStorage
      const logsToSave = this.logs.slice(-100)
      localStorage.setItem("app_logs", JSON.stringify(logsToSave))
    } catch (e) {
      console.error("Failed to save logs to localStorage:", e)
    }
  }

  private tryRestoreLogs(): void {
    if (typeof window === "undefined") return

    try {
      const savedLogs = localStorage.getItem("app_logs")
      if (savedLogs) {
        const parsedLogs = JSON.parse(savedLogs)
        // Convertir las cadenas de fecha a objetos Date
        this.logs = parsedLogs.map((log: any) => ({
          ...log,
          timestamp: new Date(log.timestamp),
        }))
      }
    } catch (e) {
      console.error("Failed to restore logs from localStorage:", e)
    }
  }
}

export const logger = Logger.getInstance()

// Hook para usar el logger en componentes
export function useLogger(module: string) {
  return {
    debug: (message: string, data?: any) => logger.debug(module, message, data),
    info: (message: string, data?: any) => logger.info(module, message, data),
    warn: (message: string, data?: any) => logger.warn(module, message, data),
    error: (message: string, data?: any) => logger.error(module, message, data),
    getLogs: (level?: LogLevel) => logger.getLogs(level, module),
  }
}
