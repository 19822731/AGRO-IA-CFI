type ErrorSeverity = "low" | "medium" | "high" | "critical"

export interface AppError {
  code: string
  message: string
  severity: ErrorSeverity
  timestamp: Date
  context?: Record<string, any>
  stack?: string
}

class ErrorService {
  private static instance: ErrorService
  private errors: AppError[] = []
  private errorHandlers: ((error: AppError) => void)[] = []
  private maxStoredErrors = 100

  private constructor() {}

  public static getInstance(): ErrorService {
    if (!ErrorService.instance) {
      ErrorService.instance = new ErrorService()
    }
    return ErrorService.instance
  }

  public captureError(
    code: string,
    message: string,
    severity: ErrorSeverity = "medium",
    context?: Record<string, any>,
    stack?: string,
  ): AppError {
    const error: AppError = {
      code,
      message,
      severity,
      timestamp: new Date(),
      context,
      stack,
    }

    // Limitar el número de errores almacenados
    if (this.errors.length >= this.maxStoredErrors) {
      this.errors.shift() // Eliminar el error más antiguo
    }

    this.errors.push(error)
    this.notifyHandlers(error)

    // Para errores críticos, también podríamos enviarlos a un servicio externo
    if (severity === "critical") {
      this.logToExternalService(error)
    }

    return error
  }

  public captureException(
    error: Error,
    code = "UNKNOWN_ERROR",
    severity: ErrorSeverity = "medium",
    context?: Record<string, any>,
  ): AppError {
    return this.captureError(code, error.message, severity, context, error.stack)
  }

  public registerErrorHandler(handler: (error: AppError) => void): () => void {
    this.errorHandlers.push(handler)

    // Devolver función para eliminar el handler
    return () => {
      this.errorHandlers = this.errorHandlers.filter((h) => h !== handler)
    }
  }

  public getRecentErrors(count = 10): AppError[] {
    return this.errors.slice(-count)
  }

  public clearErrors(): void {
    this.errors = []
  }

  private notifyHandlers(error: AppError): void {
    this.errorHandlers.forEach((handler) => {
      try {
        handler(error)
      } catch (e) {
        console.error("Error in error handler:", e)
      }
    })
  }

  private logToExternalService(error: AppError): void {
    // En el futuro, aquí se podría implementar la integración con servicios como Sentry
    console.error("CRITICAL ERROR:", error)

    // También podríamos enviar a un endpoint propio
    if (typeof window !== "undefined") {
      try {
        // Ejemplo de envío a un endpoint (comentado para no generar tráfico real)
        // fetch('/api/log-error', {
        //   method: 'POST',
        //   headers: { 'Content-Type': 'application/json' },
        //   body: JSON.stringify(error)
        // }).catch(e => console.error('Failed to send error to server:', e))
      } catch (e) {
        console.error("Failed to log error to external service:", e)
      }
    }
  }
}

export const errorService = ErrorService.getInstance()

// Hook para usar el servicio de errores en componentes
export function useErrorService() {
  return {
    captureError: errorService.captureError.bind(errorService),
    captureException: errorService.captureException.bind(errorService),
    getRecentErrors: errorService.getRecentErrors.bind(errorService),
    registerErrorHandler: errorService.registerErrorHandler.bind(errorService),
    clearErrors: errorService.clearErrors.bind(errorService),
  }
}
