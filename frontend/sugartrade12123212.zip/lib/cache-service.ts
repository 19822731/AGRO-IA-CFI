"use client"

import React from "react"

interface CacheItem<T> {
  data: T
  timestamp: number
  expiresAt: number
}

class CacheService {
  private static instance: CacheService
  private cache: Map<string, CacheItem<any>> = new Map()
  private defaultTTL: number = 5 * 60 * 1000 // 5 minutos en milisegundos

  private constructor() {
    // Limpiar caché expirada periódicamente
    if (typeof window !== "undefined") {
      setInterval(() => this.cleanExpiredCache(), 60 * 1000) // Cada minuto
    }
  }

  public static getInstance(): CacheService {
    if (!CacheService.instance) {
      CacheService.instance = new CacheService()
    }
    return CacheService.instance
  }

  public set<T>(key: string, data: T, ttl: number = this.defaultTTL): void {
    const now = Date.now()
    this.cache.set(key, {
      data,
      timestamp: now,
      expiresAt: now + ttl,
    })
  }

  public get<T>(key: string): T | null {
    const item = this.cache.get(key)

    if (!item) {
      return null
    }

    // Verificar si el ítem ha expirado
    if (Date.now() > item.expiresAt) {
      this.cache.delete(key)
      return null
    }

    return item.data as T
  }

  public remove(key: string): void {
    this.cache.delete(key)
  }

  public clear(): void {
    this.cache.clear()
  }

  public setDefaultTTL(ttl: number): void {
    this.defaultTTL = ttl
  }

  public has(key: string): boolean {
    const item = this.cache.get(key)
    if (!item) return false

    // Verificar si el ítem ha expirado
    if (Date.now() > item.expiresAt) {
      this.cache.delete(key)
      return false
    }

    return true
  }

  public getKeys(): string[] {
    return Array.from(this.cache.keys())
  }

  public getSize(): number {
    return this.cache.size
  }

  private cleanExpiredCache(): void {
    const now = Date.now()
    for (const [key, item] of this.cache.entries()) {
      if (now > item.expiresAt) {
        this.cache.delete(key)
      }
    }
  }
}

export const cacheService = CacheService.getInstance()

// Hook para usar el servicio de caché en componentes
export function useCacheService() {
  return {
    set: cacheService.set.bind(cacheService),
    get: cacheService.get.bind(cacheService),
    remove: cacheService.remove.bind(cacheService),
    clear: cacheService.clear.bind(cacheService),
    has: cacheService.has.bind(cacheService),
    getKeys: cacheService.getKeys.bind(cacheService),
    getSize: cacheService.getSize.bind(cacheService),
    setDefaultTTL: cacheService.setDefaultTTL.bind(cacheService),
  }
}

// Hook para datos con caché
export function useCachedData<T>(
  key: string,
  fetchFn: () => Promise<T>,
  options: {
    ttl?: number
    enabled?: boolean
    refetchOnMount?: boolean
  } = {},
) {
  const [data, setData] = React.useState<T | null>(null)
  const [isLoading, setIsLoading] = React.useState<boolean>(false)
  const [error, setError] = React.useState<Error | null>(null)

  const fetchData = React.useCallback(
    async (force = false) => {
      // Si está deshabilitado, no hacer nada
      if (options.enabled === false) return

      // Verificar caché primero si no es forzado
      if (!force) {
        const cachedData = cacheService.get<T>(key)
        if (cachedData) {
          setData(cachedData)
          return
        }
      }

      setIsLoading(true)
      setError(null)

      try {
        const result = await fetchFn()
        setData(result)

        // Guardar en caché
        cacheService.set(key, result, options.ttl)
      } catch (err) {
        setError(err instanceof Error ? err : new Error(String(err)))
      } finally {
        setIsLoading(false)
      }
    },
    [key, fetchFn, options.enabled, options.ttl],
  )

  // Efecto para cargar datos al montar
  React.useEffect(() => {
    const shouldRefetch = options.refetchOnMount !== false
    fetchData(!shouldRefetch)
  }, [fetchData, options.refetchOnMount])

  return {
    data,
    isLoading,
    error,
    refetch: () => fetchData(true),
    invalidateCache: () => {
      cacheService.remove(key)
      fetchData(true)
    },
  }
}
