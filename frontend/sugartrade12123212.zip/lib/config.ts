// Tipos para la configuración
export interface AppConfig {
  api: {
    baseUrl: string
    timeout: number
    retryAttempts: number
  }
  ui: {
    theme: "light" | "dark" | "system"
    animationsEnabled: boolean
    dateFormat: string
    numberFormat: {
      locale: string
      currency: string
      decimalPlaces: number
    }
  }
  features: {
    enableAnalytics: boolean
    enableNotifications: boolean
    enableOfflineMode: boolean
    experimentalFeatures: boolean
  }
  performance: {
    enableLazyLoading: boolean
    cacheTimeoutMinutes: number
  }
}

// Configuración por defecto
const defaultConfig: AppConfig = {
  api: {
    baseUrl: "/api",
    timeout: 30000,
    retryAttempts: 3,
  },
  ui: {
    theme: "dark",
    animationsEnabled: true,
    dateFormat: "dd/MM/yyyy",
    numberFormat: {
      locale: "es-AR",
      currency: "ARS",
      decimalPlaces: 2,
    },
  },
  features: {
    enableAnalytics: true,
    enableNotifications: true,
    enableOfflineMode: false,
    experimentalFeatures: false,
  },
  performance: {
    enableLazyLoading: true,
    cacheTimeoutMinutes: 15,
  },
}

// Clase para gestionar la configuración
class ConfigService {
  private static instance: ConfigService
  private config: AppConfig
  private listeners: Array<(config: AppConfig) => void> = []

  private constructor() {
    this.config = { ...defaultConfig }
    this.loadFromLocalStorage()
  }

  public static getInstance(): ConfigService {
    if (!ConfigService.instance) {
      ConfigService.instance = new ConfigService()
    }
    return ConfigService.instance
  }

  public getConfig(): AppConfig {
    return this.config
  }

  public updateConfig(partialConfig: Partial<AppConfig>): void {
    this.config = this.mergeDeep(this.config, partialConfig)
    this.saveToLocalStorage()
    this.notifyListeners()
  }

  public resetToDefaults(): void {
    this.config = { ...defaultConfig }
    this.saveToLocalStorage()
    this.notifyListeners()
  }

  public subscribe(listener: (config: AppConfig) => void): () => void {
    this.listeners.push(listener)

    // Return unsubscribe function
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener)
    }
  }

  private notifyListeners(): void {
    this.listeners.forEach((listener) => {
      try {
        listener(this.config)
      } catch (error) {
        console.error("Error in config listener:", error)
      }
    })
  }

  private loadFromLocalStorage(): void {
    if (typeof window === "undefined") return

    try {
      const savedConfig = localStorage.getItem("app_config")
      if (savedConfig) {
        const parsedConfig = JSON.parse(savedConfig)
        this.config = this.mergeDeep(this.config, parsedConfig)
      }
    } catch (error) {
      console.error("Error loading config from localStorage:", error)
      // Si hay un error, intentamos limpiar el localStorage para evitar problemas futuros
      try {
        localStorage.removeItem("app_config")
      } catch {
        // Ignorar si también falla la limpieza
      }
    }
  }

  private saveToLocalStorage(): void {
    if (typeof window === "undefined") return

    try {
      localStorage.setItem("app_config", JSON.stringify(this.config))
    } catch (error) {
      console.error("Error saving config to localStorage:", error)

      // Si el error es por cuota excedida, intentamos limpiar
      if (
        error instanceof DOMException &&
        (error.code === 22 || // cuota excedida
          error.code === 1014 || // Firefox
          error.name === "QuotaExceededError")
      ) {
        try {
          localStorage.removeItem("app_config")
          // Intentar guardar de nuevo con solo la configuración esencial
          const essentialConfig = {
            ui: { theme: this.config.ui.theme },
          }
          localStorage.setItem("app_config", JSON.stringify(essentialConfig))
        } catch {
          // Ignorar si también falla la limpieza
        }
      }
    }
  }

  // Función auxiliar para fusionar objetos de forma profunda
  private mergeDeep(target: any, source: any): any {
    const output = { ...target }

    if (this.isObject(target) && this.isObject(source)) {
      Object.keys(source).forEach((key) => {
        if (this.isObject(source[key])) {
          if (!(key in target)) {
            Object.assign(output, { [key]: source[key] })
          } else {
            output[key] = this.mergeDeep(target[key], source[key])
          }
        } else {
          Object.assign(output, { [key]: source[key] })
        }
      })
    }

    return output
  }

  private isObject(item: any): boolean {
    return item && typeof item === "object" && !Array.isArray(item)
  }
}

export const configService = ConfigService.getInstance()

// Hook para usar la configuración en componentes
export function useConfig() {
  return {
    config: configService.getConfig(),
    updateConfig: configService.updateConfig.bind(configService),
    resetToDefaults: configService.resetToDefaults.bind(configService),
    subscribe: configService.subscribe.bind(configService),
  }
}

// Funciones de utilidad para formatear datos según la configuración
export function formatDate(date: Date | string, format?: string): string {
  const config = configService.getConfig()
  const dateFormat = format || config.ui.dateFormat

  // Implementación simple, en producción usar una biblioteca como date-fns
  const d = typeof date === "string" ? new Date(date) : date

  try {
    return d.toLocaleDateString("es-AR", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    })
  } catch (error) {
    // Fallback por si hay problemas con toLocaleDateString
    const day = String(d.getDate()).padStart(2, "0")
    const month = String(d.getMonth() + 1).padStart(2, "0")
    const year = d.getFullYear()
    return `${day}/${month}/${year}`
  }
}

export function formatNumber(
  value: number,
  options?: {
    decimalPlaces?: number
    currency?: boolean
  },
): string {
  const config = configService.getConfig()
  const { locale, currency } = config.ui.numberFormat

  const decimals = options?.decimalPlaces !== undefined ? options.decimalPlaces : config.ui.numberFormat.decimalPlaces

  try {
    if (options?.currency) {
      return new Intl.NumberFormat(locale, {
        style: "currency",
        currency,
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      }).format(value)
    }

    return new Intl.NumberFormat(locale, {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(value)
  } catch (error) {
    // Fallback por si hay problemas con Intl.NumberFormat
    console.error("Error formatting number:", error)
    return options?.currency ? `${currency} ${value.toFixed(decimals)}` : value.toFixed(decimals)
  }
}

interface EnvironmentConfig {
  apiKey: string
  jwtSecret: string
  apiBaseUrl: string
  sentryDsn?: string
  otlpEndpoint?: string
  nodeEnv: string
}

// Environment configuration based on Vercel deployment setup
export const config: EnvironmentConfig = {
  apiKey: process.env.API_KEY || "",
  jwtSecret: process.env.JWT_SECRET || process.env.NEXTAUTH_SECRET || "tu-secreto-seguro",
  apiBaseUrl: process.env.API_BASE_URL || "http://localhost:8080",
  sentryDsn: process.env.SENTRY_DSN,
  otlpEndpoint: process.env.OTEL_EXPORTER_OTLP_ENDPOINT,
  nodeEnv: process.env.NODE_ENV || "development",
}

// API client configuration
export const apiConfig = {
  baseUrl: config.apiBaseUrl,
  timeout: 30000,
  headers: {
    "Content-Type": "application/json",
    // Note: API key should NOT be included in client-side headers
    // It will be added server-side in middleware or API routes
  },
}
