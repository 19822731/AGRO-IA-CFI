import { cookies, headers } from "next/headers"

function getCorrelationId() {
  const h = headers()
  return h.get("x-correlation-id") ?? crypto.randomUUID()
}

export async function bffFetch(path: string, init?: RequestInit) {
  const API_BASE_URL = process.env.API_BASE_URL
  if (!API_BASE_URL) {
    throw new Error("Missing API_BASE_URL environment variable. Please configure API_BASE_URL in your environment.")
  }

  const token = cookies().get("access_token")?.value

  const h = new Headers(init?.headers)
  h.set("x-correlation-id", getCorrelationId())
  if (token) h.set("Authorization", `Bearer ${token}`)

  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: h,
    cache: "no-store",
  })
  return res
}
