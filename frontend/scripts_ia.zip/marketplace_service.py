"""
Módulo de servicios del marketplace para la gestión de órdenes, calce y precios dinámicos.
"""
import hashlib
import logging
import random
import time as pytime
from datetime import datetime, time as dt_time
from decimal import Decimal, ROUND_DOWN, ROUND_HALF_UP
from typing import Tuple, Optional

import holidays
import pytz
from fastapi import HTTPException
from sqlalchemy import select, update
from sqlalchemy.exc import OperationalError, DBAPIError, IntegrityError
from sqlalchemy.orm import Session
from sqlalchemy.dialects.postgresql import insert
from prometheus_client import Counter, Histogram

import models
import schemas
from celery_worker import celery_app
from database import SessionLocal
from src.optimization_engine import OptimizationEngine
from src.prediction_models import PredictionModels
from app.utils.db_retry import with_db_retry

logger = logging.getLogger(__name__)

# --- Métricas Prometheus ---
MATCH_SUCCESS = Counter("match_success_total", "Matches exitosos", ["producto_id"])
MATCH_REJECT  = Counter("match_reject_total",  "Matches rechazados por reglas", ["producto_id", "razon"])
MATCH_LATENCY = Histogram("match_latency_seconds", "Latencia de _try_match", ["producto_id"])
DEADLOCK_RETRIES = Counter("deadlock_retries_total", "Reintentos por deadlock o error de serialización")

# --- Constantes y Configuración ---
COMISION_VENDEDOR   = Decimal("0.02")
COMISION_ESCASEZ    = Decimal("0.025")
COMISION_SUPERAVIT  = Decimal("0.015")
PBASE_AZUCAR        = Decimal("800.0")
K_FACTOR            = Decimal("0.001")

ZONA_HORARIA_AR = pytz.timezone("America/Argentina/Buenos_Aires")
FERIADOS_AR     = holidays.AR(years=datetime.now(ZONA_HORARIA_AR).year)

TICK_QTY   = Decimal("0.0001")
TICK_MONEY = Decimal("0.01")


# --- Utilidades ---
def quantize_money(x: Decimal) -> Decimal:
    return x.quantize(TICK_MONEY, rounding=ROUND_HALF_UP)


def quantize_qty(x: Decimal) -> Decimal:
    return x.quantize(TICK_QTY, rounding=ROUND_DOWN)


def es_horario_de_mercado() -> bool:
    ahora = datetime.now(ZONA_HORARIA_AR)
    es_habil = ahora.weekday() < 5 and ahora.date() not in FERIADOS_AR
    return es_habil and (dt_time(11, 0) <= ahora.time() < dt_time(18, 0))


def _get_cantidad_restante(orden: models.Orden) -> Decimal:
    ejecutada = orden.cantidad_ejecutada or Decimal("0")
    original  = orden.cantidad_original  or Decimal("0")
    return original - ejecutada

def _enum_member(enum_cls, *candidates: str):
    cand_lower = {c.lower() for c in candidates}
    for m in enum_cls:
        if m.name.lower() in cand_lower:
            return m
    for m in enum_cls:
        v = m.value
        if isinstance(v, str) and v.lower() in cand_lower:
            return m
    raise RuntimeError(f"No enum match for {enum_cls.__name__}: {candidates}")

def tasa_comision(producto_id: int, cantidad: Decimal, precio: Decimal) -> Decimal:
    return COMISION_VENDEDOR


def crear_orden(db: Session, orden: schemas.OrdenCrear, usuario_id: int) -> models.Orden:
    """
    Crea una nueva orden en la base de datos con validaciones de negocio.
    """
    # 1. Validaciones de Lógica de Negocio
    if orden.cantidad_original <= 0:
        raise HTTPException(status_code=400, detail="La cantidad debe ser positiva.")

    if orden.tipo_ejecucion == schemas.TipoEjecucion.limite and (orden.precio_limite is None or orden.precio_limite <= 0):
        raise HTTPException(status_code=400, detail="Las órdenes a límite deben tener un precio límite positivo.")

    if orden.tipo_ejecucion == schemas.TipoEjecucion.mercado and orden.precio_limite is not None:
        raise HTTPException(status_code=400, detail="Las órdenes a mercado no deben tener un precio límite.")

    # 2. Creación del objeto del modelo SQLAlchemy
    db_orden = models.Orden(
        usuario_id=usuario_id,
        producto_id=orden.producto_id,
        tipo_orden=models.TipoOrdenEnum[orden.tipo_orden.value],
        tipo_ejecucion=models.TipoEjecucionEnum[orden.tipo_ejecucion.value],
        precio_limite=orden.precio_limite,
        cantidad_original=quantize_qty(orden.cantidad_original),
        estado=models.EstadoOrdenEnum.abierta
    )

    # 3. Guardado en Base de Datos
    db.add(db_orden)
    db.commit()
    db.refresh(db_orden)

    logger.info(f"Orden Creada: ID={db_orden.id}, Usuario={usuario_id}, Tipo={db_orden.tipo_orden.value}, Cantidad={db_orden.cantidad_original}")

    # 4. Devolver la orden creada
    return db_orden


def get_precio_actual(db: Session, producto_id: int) -> Optional[Decimal]:
    """
    Obtiene el precio de la última transacción ejecutada para un producto.
    """
    ultima_transaccion = db.query(models.Transaccion).join(models.Orden, models.Transaccion.orden_compra_id == models.Orden.id).filter(
        models.Orden.producto_id == producto_id
    ).order_by(models.Transaccion.timestamp.desc()).first()

    if ultima_transaccion:
        return ultima_transaccion.precio_ejecucion
    else:
        return None


def get_precio_referencia_dinamico(db: Session, producto_id: int) -> Optional[Decimal]:
    """
    Obtiene el Precio de Referencia Dinámico (PRD) más reciente y válido desde la base de datos.
    """
    now = datetime.now(pytz.utc)
    # Asumimos que el 'segment' se puede mapear desde producto_id, usando un valor por defecto por ahora.
    # En una implementación real, aquí podría haber una lógica de mapeo.
    segmento_producto = "AR_total"

    prd_entry = db.query(models.PrdSeries).filter(
        models.PrdSeries.segment == segmento_producto,
        models.PrdSeries.valid_from <= now,
        (models.PrdSeries.valid_to == None) | (models.PrdSeries.valid_to > now)
    ).order_by(models.PrdSeries.valid_from.desc()).first()

    if prd_entry:
        logger.info(f"PRD encontrado para producto {producto_id} (segmento {segmento_producto}): {prd_entry.prd_value}")
        return Decimal(str(prd_entry.prd_value))
    else:
        logger.warning(f"No se encontró un PRD válido para el producto {producto_id} (segmento {segmento_producto})")
        return None


def cancelar_orden(db: Session, orden_id: int, usuario_id: int) -> models.Orden:
    """
    Cancela una orden existente si el usuario es el propietario y la orden es cancelable.
    """
    # 1. Buscar la orden y bloquear la fila para la actualización
    db_orden = db.query(models.Orden).filter(models.Orden.id == orden_id).with_for_update().first()

    # 2. Validaciones
    if not db_orden:
        raise HTTPException(status_code=404, detail="La orden no existe.")

    if db_orden.usuario_id != usuario_id:
        raise HTTPException(status_code=403, detail="No tienes permiso para cancelar esta orden.")

    if db_orden.estado not in [models.EstadoOrdenEnum.abierta, models.EstadoOrdenEnum.parcialmente_ejecutada]:
        raise HTTPException(status_code=400, detail=f"No se puede cancelar una orden en estado '{db_orden.estado.value}'.")

    # 3. Actualizar el estado
    db_orden.estado = models.EstadoOrdenEnum.cancelada
    db.commit()
    db.refresh(db_orden)

    logger.info(f"Orden Cancelada: ID={db_orden.id}, Usuario={usuario_id}")

    # 4. Devolver la orden actualizada
    return db_orden


# --- Motor de Coincidencias Robusto (P1) ---
def _lock_best_orders(session: Session, producto_id: int) -> Tuple[Optional[models.Orden], Optional[models.Orden]]:
    EO = models.EstadoOrdenEnum
    TO = models.TipoOrdenEnum
    estado_abierta = _enum_member(EO, "abierta")
    estado_parcial = _enum_member(EO, "parcialmente_ejecutada")
    tipo_compra    = _enum_member(TO, "compra")
    tipo_venta     = _enum_member(TO, "venta")

    bid = session.execute(
        select(models.Orden)
        .where(
            models.Orden.producto_id == producto_id,
            models.Orden.estado.in_([estado_abierta, estado_parcial]),
            models.Orden.tipo_orden == tipo_compra
        )
        .order_by(models.Orden.precio_limite.desc().nulls_last(),
                  models.Orden.timestamp.asc())
        .with_for_update(skip_locked=True)
        .limit(1)
    ).scalars().first()

    ask = session.execute(
        select(models.Orden)
        .where(
            models.Orden.producto_id == producto_id,
            models.Orden.estado.in_([estado_abierta, estado_parcial]),
            models.Orden.tipo_orden == tipo_venta
        )
        .order_by(models.Orden.precio_limite.asc().nulls_first(),
                  models.Orden.timestamp.asc())
        .with_for_update(skip_locked=True)
        .limit(1)
    ).scalars().first()

    return bid, ask


def _precio_ejecucion(bid: models.Orden, ask: models.Orden) -> Decimal:
    if ask.precio_limite is not None:
        return ask.precio_limite
    if bid.precio_limite is not None:
        return bid.precio_limite
    return Decimal("0")


def _try_match(session: Session, producto_id: int) -> bool:
    start_time = pytime.perf_counter()
    try:
        with session.begin_nested(): # Usar savepoints para la lógica de _try_match
            EO = models.EstadoOrdenEnum
            estado_cerrada = _enum_member(EO, "ejecutada")

            bid, ask = _lock_best_orders(session, producto_id)
            if not bid or not ask:
                MATCH_REJECT.labels(producto_id=str(producto_id), razon="no_orders").inc()
                return False

            if (bid.precio_limite is not None and ask.precio_limite is not None
                    and bid.precio_limite < ask.precio_limite):
                MATCH_REJECT.labels(producto_id=str(producto_id), razon="no_cross").inc()
                return False

            cantidad = min(_get_cantidad_restante(bid), _get_cantidad_restante(ask))
            if cantidad <= 0:
                MATCH_REJECT.labels(producto_id=str(producto_id), razon="no_quantity").inc()
                return False

            precio = _precio_ejecucion(bid, ask)
            cantidad = quantize_qty(cantidad)
            precio   = quantize_money(precio)
            bruto    = quantize_money(cantidad * precio)

            tasa = tasa_comision(producto_id, cantidad, precio)
            comision = quantize_money(bruto * tasa)
            neto_vendedor = bruto - comision

            buyer_fiat = session.execute(
                select(models.BilleteraFiat)
                .where(models.BilleteraFiat.usuario_id == bid.usuario_id)
                .with_for_update(skip_locked=True)
            ).scalar_one_or_none()

            seller_act = session.execute(
                select(models.BilleteraActivo)
                .where(models.BilleteraActivo.usuario_id == ask.usuario_id,
                       models.BilleteraActivo.producto_id == producto_id)
                .with_for_update(skip_locked=True)
            ).scalar_one_or_none()

            if not buyer_fiat or not seller_act:
                MATCH_REJECT.labels(producto_id=str(producto_id), razon="no_wallet").inc()
                return False

            res = session.execute(
                update(models.BilleteraFiat)
                .where(models.BilleteraFiat.id == buyer_fiat.id,
                       models.BilleteraFiat.saldo >= bruto)
                .values(saldo=models.BilleteraFiat.saldo - bruto)
                .returning(models.BilleteraFiat.id)
            ).first()
            if not res:
                MATCH_REJECT.labels(producto_id=str(producto_id), razon="insufficient_funds").inc()
                return False

            res = session.execute(
                update(models.BilleteraActivo)
                .where(models.BilleteraActivo.id == seller_act.id,
                       models.BilleteraActivo.cantidad >= cantidad)
                .values(cantidad=models.BilleteraActivo.cantidad - cantidad)
                .returning(models.BilleteraActivo.id)
            ).first()
            if not res:
                raise RuntimeError("Activos insuficientes en vendedor")

            bid_ejecutada_prev = bid.cantidad_ejecutada or Decimal("0")
            ask_ejecutada_prev = ask.cantidad_ejecutada or Decimal("0")

            bid.cantidad_ejecutada = quantize_qty(bid_ejecutada_prev + cantidad)
            ask.cantidad_ejecutada = quantize_qty(ask_ejecutada_prev + cantidad)
            if _get_cantidad_restante(bid) == 0:
                bid.estado = estado_cerrada
            if _get_cantidad_restante(ask) == 0:
                ask.estado = estado_cerrada

            seller_fiat = session.execute(
                select(models.BilleteraFiat)
                .where(models.BilleteraFiat.usuario_id == ask.usuario_id)
                .with_for_update(skip_locked=True)
            ).scalar_one_or_none()
            if not seller_fiat:
                raise RuntimeError("Billetera fiat del vendedor no encontrada")

            session.execute(
                update(models.BilleteraFiat)
                .where(models.BilleteraFiat.id == seller_fiat.id)
                .values(saldo=models.BilleteraFiat.saldo + neto_vendedor)
            )

            stmt_upsert = (
                insert(models.BilleteraActivo)
                .values(usuario_id=bid.usuario_id, producto_id=producto_id, cantidad=Decimal("0"))
                .on_conflict_do_nothing(index_elements=["usuario_id", "producto_id"])
            )
            session.execute(stmt_upsert)

            buyer_act = session.execute(
                select(models.BilleteraActivo)
                .where(models.BilleteraActivo.usuario_id == bid.usuario_id,
                       models.BilleteraActivo.producto_id == producto_id)
                .with_for_update(skip_locked=True)
            ).scalar_one()

            session.execute(
                update(models.BilleteraActivo)
                .where(models.BilleteraActivo.id == buyer_act.id)
                .values(cantidad=models.BilleteraActivo.cantidad + cantidad)
            )

            raw  = f"{bid.id}|{ask.id}|{bid_ejecutada_prev}|{ask_ejecutada_prev}".encode()
            idem = hashlib.sha256(raw).hexdigest()

            stmt_tx = (
                insert(models.Transaccion)
                .values(
                    idempotency_key=idem,
                    orden_compra_id=bid.id,
                    orden_venta_id=ask.id,
                    cantidad_ejecutada=cantidad,
                    precio_ejecucion=precio,
                    comision_plataforma=comision,
                )
                .on_conflict_do_nothing(index_elements=["idempotency_key"])
                .returning(models.Transaccion.id)
            )

            row = session.execute(stmt_tx).first()
            if not row:
                MATCH_REJECT.labels(producto_id=str(producto_id), razon="idempotency_skip").inc()
                return False

            tx_id = row[0]

            session.execute(
                insert(models.LedgerComision)
                .values(transaccion_id=tx_id, monto=comision, moneda="ARS")
                .on_conflict_do_nothing(index_elements=["transaccion_id"])
            )

            logger.info(f"Calce OK: {cantidad} @ {precio} (bruto {bruto}, comisión {comision})")
            MATCH_SUCCESS.labels(producto_id=str(producto_id)).inc()
            return True
    finally:
        MATCH_LATENCY.labels(producto_id=str(producto_id)).observe(pytime.perf_counter() - start_time)


def _run_match_loop(db: Session, producto_id: int) -> int:
    """Función helper que contiene el bucle de calces para ser reintentado."""
    matches = 0
    while matches < 50:  # Límite de seguridad para evitar bucles infinitos
        with db.begin(): # Inicia una transacción por cada intento de calce
            if not _try_match(db, producto_id):
                break
            matches += 1
    return matches

@celery_app.task(bind=True)
def ejecutar_calce(self, producto_id: int):
    if not es_horario_de_mercado():
        logger.info("MOTOR DETENIDO: Mercado cerrado.")
        return

    logger.info(f"⚡️ INICIO CALCE producto={producto_id}")
    
    try:
        with SessionLocal() as db:
            matches = with_db_retry(
                lambda: _run_match_loop(db, producto_id),
                retry_on=(OperationalError, DBAPIError),
                non_retryable=(IntegrityError,)
            )
        logger.info(f"FIN CALCE producto={producto_id}: {matches} calces realizados")
    except Exception as e:
        logger.error(f"Error irrecuperable en calce producto={producto_id}: {e}", exc_info=True)
        # Opcionalmente, reintentar la tarea Celery si el error es de un tipo específico
        # raise self.retry(exc=e)
