from database import SessionLocal, engine
import models
import security # <--- IMPORTANTE: Importar nuestro módulo de seguridad

db = SessionLocal()

def seed_database():
    print("Poblando la base de datos con datos iniciales (versión corregida)...")

    # --- Crear Usuarios con Contraseñas Hasheadas ---
    usuario1 = models.Usuario(
        id=1, 
        email="comprador@agro.ia", 
        hashed_password=security.get_password_hash("password123") # <-- CORRECCIÓN
    )
    usuario2 = models.Usuario(
        id=2, 
        email="vendedor@agro.ia", 
        hashed_password=security.get_password_hash("password456") # <-- CORRECCIÓN
    )

    db.add_all([usuario1, usuario2])
    db.commit()

    # --- Crear Billeteras de Dinero (Fiat) ---
    billetera_fiat_1 = models.BilleteraFiat(usuario_id=1, saldo=1000000.0)
    billetera_fiat_2 = models.BilleteraFiat(usuario_id=2, saldo=0.0)

    db.add_all([billetera_fiat_1, billetera_fiat_2])
    db.commit()

    # --- Crear Billeteras de Activos (Warrants) ---
    billetera_activo_2 = models.BilleteraActivo(usuario_id=2, producto_id=2, cantidad=15.0)

    db.add(billetera_activo_2)
    db.commit()

    print("✅ Base de datos poblada con éxito.")

if __name__ == "__main__":
    models.Base.metadata.drop_all(bind=engine)
    models.Base.metadata.create_all(bind=engine)
    seed_database()